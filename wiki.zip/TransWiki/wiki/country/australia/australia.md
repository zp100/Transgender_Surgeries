**Australia**

**<span class="internal">[Wiki Index](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/index/index.md)</span>**

---

There's far more in the wiki than the pages listed here, but its a start.

[Transhub](https://www.transhub.org.au/) is a very good introduction to all things transgender in NSW, and I would expect most of it is applicable to all Australia.

General reddit resources

* [r/transgenderau](https://www.reddit.com/r/transgenderau) is the Australian trans sub, and look at their [wiki](https://www.reddit.com/r/transgenderau/wiki/index)
* [r/asktransgender](https://www.reddit.com/r/asktransgender) is a very large trans sub
* [r/ftm](https://www.reddit.com/r/ftm)
* [r/mtf](https://www.reddit.com/r/mtf)
* [r/TransLater](https://www.reddit.com/r/TransLater) for the older trans people

Other

* https://trans101.org.au/

<br />

# Minors

* https://www.minus18.org.au/
* https://gendercentre.org.au/
* https://www.twenty10.org.au/

<br />

---

# HRT

Wiki pages

* <span class="internal">[HRT Introduction](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/hrt/hrt.md)</span>
* <span class="internal">[HRT in Australia](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/hrt/australia/australia.md)</span> lists doctor prescribing HRT and reviews
* <span class="internal">[Compounding Pharmacies](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/compounding-pharmacies/australia/australia.md)</span>
* <span class="internal">[Australian Psychiatrists & Therapists](https://github.com/zp100/Transgender_Surgeries/blob/main/TransSurgeriesWiki/wiki/psychs/australia/australia.md)</span>

<br />

# Hair removal

* <span class="internal">[Hair Removal](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/hair-removal/hair-removal.md)</span>

<br />

# Surgery

Wiki pages

* <span class="internal">[Introduction](https://github.com/zp100/Transgender_Surgeries/blob/main/TransSurgeriesWiki/wiki/index/index.md)</span>
* <span class="internal">[Facial Feminisation Surgery](https://github.com/zp100/Transgender_Surgeries/blob/main/TransSurgeriesWiki/wiki/ffs/australia/australia.md)</span>
* <span class="internal">[Male to Female Genital Surgery](https://github.com/zp100/Transgender_Surgeries/blob/main/TransSurgeriesWiki/wiki/srs/australia/australia.md)</span>
* <span class="internal">[Voice Feminisation Surgery](https://github.com/zp100/Transgender_Surgeries/blob/main/TransSurgeriesWiki/wiki/vfs/australia/australia.md)</span>

Other popular destinations for surgery

* <span class="internal">[Thailand for genital surgery](https://github.com/zp100/Transgender_Surgeries/blob/main/TransSurgeriesWiki/wiki/srs/thailand/thailand.md)</span>
* <span class="internal">[Facial Team](https://github.com/zp100/Transgender_Surgeries/blob/main/TransSurgeriesWiki/wiki/ffs/europe/europe.md#facial-team)</span> in Spain for FFS
* <span class="internal">[Yeson in Korea](https://github.com/zp100/Transgender_Surgeries/blob/main/TransSurgeriesWiki/wiki/vfs/korea/korea.md#hyung-tae-kim-yeson)</span> for Voice Feminization surgery

<br />

---

# Voice

* https://www.gendervoicecentre.com.au/ - online voice training

<br />

---

# Employment

reddit

* [Coming out at work...](https://www.reddit.com/r/transgenderau/comments/jct0z4/coming_out_at_work/) by BecAwakens in 2020

<br />

---

# Hairdressers

reddit

* [Trans kid friendly hairdresser in Sydney](https://www.reddit.com/r/transgenderau/comments/oy9cpj/trans_kid_friendly_hairdresser_in_sydney/) by crossstitchwizard in 2021

Other

* https://www.strandsfortrans.com
* https://www.welcomehere.org.au
 

<br />

---

# Social Groups

<br />

---

# Trans Friendly Businesses

Welcome Here Project lists businesses across Australia

* https://www.welcomehere.org.au - *"The Welcome Here website is a project of ACON"*

<br />

## Australia

* [LGBTQ Australia & New Zealand](https://www.facebook.com/groups/322752484886318/)
* [LGBT Australia 🌈](https://www.facebook.com/groups/122272344609821/) - *"LGBT Community Chat - Friendship - Support - Advice - Love"*
* https://transprideaustralia.org.au/

<br />

## New South Wales

* The [Sydney Gender Center](https://gendercentre.org.au/) has popular social groups (before Covid)

Meetup.com

* [Sydney's Transgender Friendship](https://www.meetup.com/Sydneys-Transgender-Friendship/) - *"This group is for people who are MtF, FtM, Non-Binary or Genderqueer. It is not open to those who identify as cross dressers, transvestites or admirers. "*
* [Qtpies: Queer & Trans Gamers Collective](https://www.meetup.com/en-AU/Game-Lovers/events/285916941/) in Redfern, Sydney - *"Calling all queer and trans cutie pies and cardboard warriors for some twee tabletop gaming every Tuesday night, 6:30pm till close."*

Facebook

* [Sydney's Transgender Friendship](https://www.facebook.com/groups/sydneystransgenderfriendship) - *"This group is for people who are MtF, FtM, Non-Binary or Genderqueer. It is not open to those who identify as cross dressers, transvestites or admirers."*
* [Trans Action Warrang- Sydney](https://www.facebook.com/transactionwarrang/) - *"Trans rights are human rights and we won't be erased! We are trans people organising and fighting for our collective rights and needs in Warrang (Sydney)"*

reddit

* [Anyone in Sydney looking for new friends?](https://www.reddit.com/r/transgenderau/comments/uq5rmb/anyone_in_sydney_looking_for_new_friends/) by Yumi_NS in 2022

<br />

## Queensland

Facebook

* [Trans Brisbane](https://www.facebook.com/groups/1621123244785958/) - *"Trans-Action is a community for Transgender and fellow LGBTQIA+ members. We are based in Brisbane, Australia. We are a collective community of individuals lead by transgender people and made up of a unified body of transgender people and cisgender allies."*
* [home - queensland young trans and gender diverse people](https://www.facebook.com/groups/381896459571399) - *"home is a support group for trans, gender diverse and questioning individuals aged 16 - 30 years old. We are run by the QUT Guild Queer Collective, and based at QUT Kelvin Grove, C Block. All are welcome, you do not need to be a QUT student to join us."*
    * reddit post [Brisbane: New support group for young trans people!](https://www.reddit.com/r/transgenderau/comments/kvi4bd/brisbane_new_support_group_for_young_trans_people/) by AntifaCatgirlsRiseUp in 2021

reddit

* [Need qld resources for ftm tween](https://www.reddit.com/r/transgenderau/comments/qgkkw8/need_qld_resources_for_ftm_tween/) by lilycamille in 2021

<br />

## South Australia

Facebook

* [TransMascSA](https://www.facebook.com/TransMascSA/) - South Australia

<br />

## Tasmania

https://www.workingitout.org.au - *"Working It Out is Tasmania's sexuality, gender and intersex status support and education service. Working It Out provides support and advocacy services for lesbian, gay, bisexual, transgender, intersex and queer (LGBTIQ+) Tasmanians and education and training programmes to schools, workplaces, government and non-government organisations."*

reddit

* reply to [I feel like I'm losing my teen years to dysphoria](https://www.reddit.com/r/transgenderau/comments/wdexvn/i_feel_like_im_losing_my_teen_years_to_dysphoria/iim3h7q/) by calamurri13 in 2022 - *"Working It Out has been really nice in my experience. I'd highly recommend it. They have a gender diverse group once a month in person and a general queer group meet-up too. From there they also have connections with pretty much every queer group in the state. I've been able to meet some lovely people through it. If you also want additional one-on-one support, you can get involved with their Working It Out Together program."*

<br />

## Victoria

[The Shed](https://www.ftmshed.com.au) - *"We are a Melbourne based support group for trans masculine people, including people who are non-binary and those who are questioning or exploring their gender. We meet up to support each other and build resilience through sharing personal experiences of trans life."*

Facebook

* [Melbourne trans fam](https://www.facebook.com/groups/214655525607296/) - *"Safe group for trans people in Melbourne! Events, general discussions and positivity are what are usually posted here."*

Fitness

* https://www.tgenerationtraining.com - *"T Generation is setting a new standard for how Trans and Gender Diverse humans are accessing the world of health, fitness, and mental fortitude."*
    * 412 Lygon St, ***Brunswick East*** VIC 3057

<br />

## Western Australia

Facebook

* [TRANS IN WA (Western Australia)](https://www.facebook.com/groups/transinwa/) *"Welcome to Trans in WA. A group supporting the health and well-being of the Transsexual, Transgender and Gender Diverse community in Western Australia. It is open for all Transsexual, Transgender and Gender Diverse people including their families."*
* [Perth Non-Binary, Genderqueer, Trans Social Group](https://www.facebook.com/groups/937434653008746) - *"A Perth-based social meetup group for non-binary, genderqueer, trans and other gender diverse folk :)"*
* [TransFolk of WA](https://www.facebook.com/TransFolkofWA) - *"TransFolk of WA is a support service for trans and gender diverse people and their loved ones in Western Australia."*

<br />

## Facebook groups

Australian Facebook groups

* [Transgender/Gender Diverse Neurodiversity Squad Australia](https://www.facebook.com/groups/transneurodiversitysquadaus/) - *"This is a place for transgender and gender diverse people who are autistic, have ADHD or other neurodiverse conditions AND live in the country known as Australia."*
* [TransFolk of Western Australia](https://www.facebook.com/TransFolkofWA) - *"TransFolk of WA is a support service for trans and gender diverse people and their loved ones in Western Australia."*
* [Transgender Surgery Australia NZ - FFS Facial Feminisation Surgery, GCS](https://www.facebook.com/groups/TransSurgeryANZ/)  
* [Aussie FTM 🇦🇺](https://www.facebook.com/groups/304230233317557/)
* [NovaTrue - Trans and Gender Diverse Health and Social Advocacy](https://www.facebook.com/groups/NovaTrue/) - *"Born from the mysterious resignation of prominent endocrinologist Dr Jon Hayes, a pioneer of transgender medicine, NovaTrue seeks to advocate for better healthcare and social progress for trans and gender diverse peeps"*
* https://www.facebook.com/TransgenderTasmania - *"Transgender Tasmania's mission is to provide events, forums and resources for the transgender community and their friends and family."*

Other Facebook groups

* <span class="internal">[r/TransWiki/wiki/facebook](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/facebook/facebook.md)</span>

<br />

---

# Support Services

## Headspace

I'm not entirely sure what they do, but something to do with youth support services.

Key details

* https://headspace.org.au/
* https://headspace.org.au/young-people/gender-identity-and-mental-health/

<br />

### Queensland

#### Southport

Key details

* Level 1, H20 Broadwater, 1/2 Nind Street, Southport, Queensland 4215
* https://headspace.org.au/headspace-centres/southport/

reddit

* reply to [Do NOT go to headspace in Bendigo](https://www.reddit.com/r/transgenderau/comments/kcj7pm/do_not_go_to_headspace_in_bendigo/gfrzp6r/) by WinWin369 in 2020

<br />

### Victoria

#### Ballarat

Key details

* 28 Camp Street, Ballarat, Victoria 3350
* https://headspace.org.au/headspace-centres/ballarat

* reply to [Do NOT go to headspace in Bendigo](https://www.reddit.com/r/transgenderau/comments/kcj7pm/do_not_go_to_headspace_in_bendigo/gfqykv2/) by jackjwm in 2020

<br />

#### Bendigo

Key details

* 78-80 Pall Mall, Bendigo, Victoria 3550
* https://headspace.org.au/headspace-centres/bendigo

reddit

* [Do NOT go to headspace in Bendigo](https://www.reddit.com/r/transgenderau/comments/kcj7pm/do_not_go_to_headspace_in_bendigo/) by gaygender in 2020

<br />

---

# Moving to Australia

reddit

* [How hard is it to get HRT in AU?](https://www.reddit.com/r/transgenderau/comments/vwk3kc/how_hard_is_it_to_get_hrt_in_au/) by Complete-Anon in 2022
* [How long are the wait times and is Australian trans healthcare good?](https://www.reddit.com/r/transgenderau/comments/u9rk30/how_long_are_the_wait_times_and_is_australian/) by CantDecideANam3 in 2022
* [Receiving Gender-Affirming Care in Australia](https://www.reddit.com/r/transgenderau/comments/tyngjq/receiving_genderaffirming_care_in_australia/) by Daez666 in 2022
* [How are trans people treated in Australia?](https://www.reddit.com/r/transgenderau/comments/qfq7q8/how_are_trans_people_treated_in_australia/) by ChalcedonyCat in 2021
* [SOme questions from someone trans who wants to hopefully migrate to Australia.](https://www.reddit.com/r/transgenderau/comments/jhheex/some_questions_from_someone_trans_who_wants_to/) by jfkmathrowaway in 2020
* [What's it like to transition in Australia?](https://www.reddit.com/r/transgenderau/comments/jgs6r4/whats_it_like_to_transition_in_australia/) by darkangel2881 in 2020
 
Australian Government - Services Australia

* [Visiting from the United Kingdom](https://www.servicesaustralia.gov.au/reciprocal-health-care-agreements-visiting-from-united-kingdom?context=22481) - If you’re visiting Australia from the United Kingdom you may be eligible for medical care under Medicare while you’re here.
 

<br />

---

# Misc

Facebook

* https://www.facebook.com/SydneyTDoR - *"Official page for Sydney's Official Transgender Day of Remembrance Observance and Candlelight Vigil held annually on November 20."*
* https://www.facebook.com/sydneytransgender - *"Sydney Transgender is Australia's leading agency for the management of transgender talent."*, see also Www.sydneytransgender.com
* https://www.facebook.com/TransHousingNetwork

---

**<span class="internal">[Wiki Index](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/index/index.md)</span>**
