**VFS Australia**

**<span class="internal">[Wiki Index](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/index/index.md)</span>**

---

Facebook Groups

* [Voice Feminization Surgery](https://www.facebook.com/groups/1332887563555093/)

# Voice training

Gender Voice Center

* https://www.gendervoicecentre.com.au/ - online voice training

reddit

* [Anyone from Newcastle know of anyone that does vocal training around here?](https://www.reddit.com/r/transgenderau/comments/ed50fp/anyone_from_newcastle_know_of_anyone_that_does/) by Due_Link in 2019

Susans

* [Feminising voice pathologists in Sydney.](https://www.susans.org/forums/index.php?topic=201980.0) by roxie rudi in 2019

Other

* http://www.catemadill.com.au/voice-problems/transgender-voice/

---

# ACT

## Theo Athanasiadis

Location

* Adelaide

Surgeons sites

* http://ahent.com.au
* https://healthengine.com.au/ent-specialist/sa/adelaide/dr-theodore-athanasiadis/p41793
* http://www.theajo.com/user/view/60683
* https://surgeons.org/profile/dr-theodore-athanasiadis

Susans

* [Update on Dr Theodore Athanasiadis](https://www.reddit.com/r/transgenderau/comments/dwkr2u/update_on_dr_theodore_athanasiadis/) by AstralEuphoria in 2019
* [Dr Theodore Athanasiadis](https://www.reddit.com/r/transgenderau/comments/dvmubj/dr_theodore_athanasiadis/) by AstralEuphoria in 2019
* [An Adelaide Girls VFS surgery](https://www.susans.org/forums/index.php/topic,244154.0.html) by LizK in 2019

---

# New South Wales

---

# Queensland

## Matthew Broadhurst

Location

* Brisbane

Surgeons sites

* https://www.entdoctor.com.au/

reddit

* [Transfemme PSA: Tracheal shave in Aus](https://www.reddit.com/r/TransgenderNZ/comments/oxj6ou/transfemme_psa_tracheal_shave_in_aus/) by guessimfine in 2021
* [CTA vs Femlar voice surgery](https://www.reddit.com/r/transgenderau/comments/p3e9fu/cta_vs_femlar_voice_surgery/) by fullbrooks in 2021
* [Anyone had voice surgery with Matthew Broadhurst? Looking for advice.](https://www.reddit.com/r/transgenderau/comments/lnxs6l/anyone_had_voice_surgery_with_matthew_broadhurst/) by  Larkias in 2021
* [I just had a femlar procedure with Dr Matthew broadhurst. AMA](https://www.reddit.com/r/transgenderau/comments/f53tgg/i_just_had_a_femlar_procedure_with_dr_matthew/) by dasteph69 in 2020
* [I just booked my Femlar procedure with Dr. Matthew Broadhurst, in Queensland AU](https://www.reddit.com/r/Transgender_Surgeries/comments/e9lt9q/i_just_booked_my_femlar_procedure_with_dr_matthew/) by ehecatlinoz in 2019
* [Dr Matthew broadhurst](https://www.reddit.com/r/transgenderau/comments/d5e7mw/dr_matthew_broadhurst/) by MaddieDeane in 2019
* [Does anyone got removed Adam’s apple removed in Australia?](https://www.reddit.com/r/transgenderau/comments/di6mh5/does_anyone_got_removed_adams_apple_removed_in/) by Samy3108 in 2019
* [Vocal Surgery In Australia](https://www.reddit.com/r/transgenderau/comments/apqnp3/vocal_surgery_in_australia/) by TGJess in 2019
* [FemLar - larynx reconstruction](https://www.reddit.com/r/transgenderau/comments/9owro8/femlar_larynx_reconstruction/) by -Jaz in 2018

## Elizabeth Hodge

Location

* Brisbane

Surgeons sites

* https://brizent.com/
* https://brizent.com/ent-conditions/throat/voice-feminisation - *"Dr Hodge has undertaken formal training in surgical voice feminisation techniques. For 12 months she worked with Mr Guri Sandhu at Charing Cross Hospital in London, where the Gender Identity Clinic was based."*
* https://www.healthshare.com.au/profile/professional/197008-dr-elizabeth-hodge/

---

# South Australia

---

# Tasmania

---

# Victoria

## Paul M. Paddle

Location

* Melbourne

Surgeons sites

* https://paulpaddle.com.au/
* https://melbentgroup.com.au/about-us/dr-paul-paddle/
* https://mvac.com.au/our_team/mr-paul-m-paddle/
* https://www.ramsayhealth.com.au/Specialists/waverley-private-hospital/ear-nose-and-throat/104721/mr-paul-paddle
* https://australianvoiceassociation.com.au/about-us/

reddit

* [Health Insurance for Voice Feminisation?](https://www.reddit.com/r/transgenderau/comments/q9rg9r/health_insurance_for_voice_feminisation/) by frostypls in 2021
* [CTA vs Femlar voice surgery](https://www.reddit.com/r/transgenderau/comments/p3e9fu/cta_vs_femlar_voice_surgery/) by fullbrooks in 2021
* [Update on Dr Theodore Athanasiadis](https://www.reddit.com/r/transgenderau/comments/dwkr2u/update_on_dr_theodore_athanasiadis/) by AstralEuphoria in 2019
* [La Trobe Voice Clinic... Worth the wait?](https://www.reddit.com/r/transgenderau/comments/ctkmjw/la_trobe_voice_clinic_worth_the_wait/) by dk0222 in 2019
* [Does anyone have experience with Dr Paul Paddle in Melbourne?](https://www.reddit.com/r/transgenderau/comments/azlzv8/does_anyone_have_experience_with_dr_paul_paddle/) by zoetrope_ in 2019

Papers

* https://www.researchgate.net/profile/Paul_Paddle

---

# Western Australia

# Northern Territory

---

**<span class="internal">[Wiki Index](https://github.com/zp100/Transgender_Surgeries/blob/main/TransWiki/wiki/index/index.md)</span>**
